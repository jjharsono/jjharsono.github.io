'''
----------------------------------------
Assignment: 3.2.7 Data Visualization
Partners: Noah Allen and Justin Harsono
Client: Janson Law, Alex Lill, Harish Raman
----------------------------------------
'''

#Import Statements
import matplotlib.pyplot as plt
import os.path

#Defines variables and opens the file from our folder
directory = os.path.dirname(os.path.abspath(__file__))

#Imports and defines the data for 2005
filename1 = os.path.join(directory, 'Data File 2005.csv')
datafile1 = open(filename1,'r')
data_2005 = datafile1.readlines()

#Imports and defines the data for 2005
filename2 = os.path.join(directory, 'Data File 2012.csv')
datafile2 = open(filename2,'r')
data_2012 = datafile2.readlines()

#Define the two data lists
histData_2005 = []
histData_2012 = []

#Iterates through a for loop to add our needed data points to the 2005 list
for line in data_2005[1:]:
    state, percentLGBTQ_2005 = line.split(',')
    histData_2005.append(float(percentLGBTQ_2005[:-1]) * .01)
    
#Iterates through a for loop to add our needed data points to the 2005 list
for line in data_2012[1:]:
    state, percentLGBTQ_2012 = line.split(',')
    histData_2012.append(float(percentLGBTQ_2012[:-1]) * .01)

userInput = raw_input("Which Display Would You Like to See? Histogram or Boxplot: ") 

#If the user wants a histogram, run this if statement
if userInput == "histogram" or userInput == "Histogram":
    
    #Configures window size
    fig, ax  = plt.subplots(1, 2, figsize = (20, 10))
    
    #Runs a for loop setting common traits equal to eachother on both windows
    for i in range(0, 2):
        ax[i].set_ylim(0, 20)
        ax[i].set_xlim(0, .11)
        ax[i].set_ylabel("Number of States")
        ax[i].set_xlabel("Proportion of People Who Identify as LGBT")
        
    #Defines the means used for the average line
    mean2005 = (sum(histData_2005)/len(histData_2005))
    mean2012 = (sum(histData_2012)/len(histData_2012))
    
    #Creates the average lines for each histogram
    ax[0].axvline(mean2005, color="k", linewidth = 2, linestyle = "dashed")
    ax[1].axvline(mean2012, color="k", linewidth = 2, linestyle = "dashed")
    
    #Sets the title
    ax[0].set_title('2005 Data')
    ax[1].set_title('2012 Data')
    
    #Applies our data to a histogram window and displays it
    ax[0].hist(histData_2005, color = "red" , bins = 15)
    ax[1].hist(histData_2012, color ="blue", bins = 15)
    fig.show()

#If the user wants a boxplot, run this if statement
if userInput == "Boxplot" or userInput == "boxplot":
    
    #Configures the window size
    fig, ax = plt.subplots(1,1, figsize = (10, 5))
   
    #Defines the characteristics of the window and boxplot
    ax.set_ylabel("Proportion of People Who Identify as LGBT")
    ax.boxplot([histData_2005, histData_2012], patch_artist=True, labels = [2005, 2012], sym = ('*'))
    fig.show()
        